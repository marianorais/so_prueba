#ifndef CPU_MAIN_H
#define CPU_MAIN_H

#include <stdlib.h>
#include <stdio.h>
#include "../include/init_cpu.h"
#include <utils/utils.h>
#include <signal.h>
#include "../include/cpu_utils.h"
#include "../include/server_cpu.h"




void ejecutar_ciclo() ;






#endif //CPU_MAIN_H