#ifndef INIT_FS_MAIN_H
#define INIT_FS_MAIN_H

#include "../include/init_filesystem.h"
#include "../include/estructuras_fs.h"
#include"../include/server_fs.h"
#endif /* INIT_FS_MAIN_H */