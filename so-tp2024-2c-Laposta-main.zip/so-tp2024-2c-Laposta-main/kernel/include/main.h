#ifndef MAIN_H_
#define MAIN_H_
#include "init_kernel.h"

#endif /* MAIN_H_ */