#ifndef MAIN_H
#define MAIN_H

#include <stdlib.h>
#include <stdio.h>
#include <utils/utils.h>

#include "../include/conexion.h"
#include "../include/init_memoria.h"

#endif