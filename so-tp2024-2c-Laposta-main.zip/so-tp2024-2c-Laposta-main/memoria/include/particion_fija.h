#ifndef PARTICION_FIJA_H
#define PARTICION_FIJA_H

#include <pthread.h>
#include <commons/string.h>

#include <stdlib.h>
#include <stdio.h>
#include <utils/utils.h>

#include "../include/init_memoria.h"


//----------------------------------Estructuras---------------------------------



//----------------------------------Variables Externs-------------------------



//----------------------------------Prototipos---------------------------------


#endif 